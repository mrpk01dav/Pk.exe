import { useEffect, useState } from 'react';
import { profile } from './data/profile';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Skills from './components/Skills';
import Projects from './components/Projects';
import Journey from './components/Journey';
import Contact from './components/Contact';
import Footer from './components/Footer';

export const sections = ['home', 'about', 'skills', 'projects', 'journey', 'contact'];

export default function App() {
  const [theme, setTheme] = useState(() => document.documentElement.dataset.theme || 'dark');
  const [active, setActive] = useState('home');
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    try { localStorage.setItem('pk-theme', theme); } catch { /* storage blocked */ }
  }, [theme]);

  useEffect(() => {
    const io = new IntersectionObserver(
      (es) => es.forEach((e) => e.isIntersecting && setActive(e.target.id)),
      { rootMargin: '-40% 0px -55% 0px' }
    );
    sections.forEach((id) => { const el = document.getElementById(id); el && io.observe(el); });
    const reveal = new IntersectionObserver(
      (es) => es.forEach((e) => e.isIntersecting && e.target.classList.add('in')),
      { threshold: 0.12 }
    );
    document.querySelectorAll('.reveal').forEach((el) => reveal.observe(el));
    const onScroll = () => {
      const h = document.documentElement.scrollHeight - innerHeight;
      setProgress(h > 0 ? (scrollY / h) * 100 : 0);
    };
    addEventListener('scroll', onScroll, { passive: true });
    return () => { io.disconnect(); reveal.disconnect(); removeEventListener('scroll', onScroll); };
  }, []);

  return (
    <>
      <a className="skip" href="#main">Skip to content</a>
      <div className="progress" style={{ width: progress + '%' }} aria-hidden="true" />
      <Navbar active={active} theme={theme} setTheme={setTheme} />
      <main id="main">
        <Hero />
        <About />
        <Skills />
        <Projects />
        <Journey />
        <Contact />
      </main>
      <Footer />
      <button className={'totop' + (progress > 15 ? ' show' : '')} aria-label="Back to top" onClick={() => scrollTo({ top: 0, behavior: 'smooth' })}>↑</button>
    </>
  );
}
