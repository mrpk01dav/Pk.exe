import { profile } from '../data/profile';
export default function Footer() {
  const soc = Object.entries(profile.social).filter(([, v]) => v);
  return (
    <footer className="foot"><div className="wrap foot-in">
      <div><a href="#home" className="logo">PK<span>.exe</span></a><p className="muted">{profile.tagline}</p></div>
      <nav aria-label="Footer">{soc.map(([k, v]) => <a key={k} href={v} target="_blank" rel="noopener noreferrer">{k}</a>)}<a href="#top" onClick={(e) => { e.preventDefault(); scrollTo({ top: 0, behavior: 'smooth' }); }}>Back to top</a></nav>
      <p className="muted">© {new Date().getFullYear()} {profile.name}</p>
    </div></footer>
  );
}
