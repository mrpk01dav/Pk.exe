import { useEffect, useRef } from 'react';
export default function ProjectDetails({ project: p, onClose }) {
  const ref = useRef(null);
  useEffect(() => {
    const prev = document.body.style.overflow; document.body.style.overflow = 'hidden';
    ref.current?.focus();
    const k = (e) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'Tab') { // focus trap
        const f = ref.current.querySelectorAll('a[href],button'); if (!f.length) return;
        const a = f[0], z = f[f.length - 1];
        if (e.shiftKey && document.activeElement === a) { e.preventDefault(); z.focus(); }
        else if (!e.shiftKey && document.activeElement === z) { e.preventDefault(); a.focus(); }
      }
    };
    addEventListener('keydown', k);
    return () => { document.body.style.overflow = prev; removeEventListener('keydown', k); };
  }, [onClose]);
  const d = p.detail;
  const Row = ({ h, children }) => <><h4>{h}</h4>{children}</>;
  return (
    <div className="modal-bg" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal" role="dialog" aria-modal="true" aria-labelledby="pd-title" tabIndex={-1} ref={ref}>
        <button className="icon close" aria-label="Close project details" onClick={onClose}>✕</button>
        <p className="eyebrow">{p.category} · {p.status}</p>
        <h2 id="pd-title">{p.name}</h2><p className="muted">{p.description}</p>
        <Row h="Problem being solved"><p>{d.problem}</p></Row>
        <Row h="Design approach"><p>{d.approach}</p></Row>
        <Row h="Verified features">{p.features.length
          ? <ul className="list">{p.features.map((f) => <li key={f}>{f}</li>)}</ul>
          : <p className="muted">Feature list is being verified against the deployed app. Nothing is claimed until tested.</p>}</Row>
        <Row h="Technology"><ul className="chips">{p.stack.map((s) => <li key={s}>{s}</li>)}</ul></Row>
        <Row h="Screenshots">{d.screenshots.length
          ? d.screenshots.map((s) => <img key={s} src={s} alt={p.name + ' screenshot'} loading="lazy" />)
          : <p className="muted">Screenshots coming soon.</p>}</Row>
        <Row h="Known limitations"><p className="muted">{d.limitations}</p></Row>
        <Row h="Lessons learned"><p className="muted">{d.lessons}</p></Row>
        <div className="row">
          {p.live && <a className="btn" href={p.live} target="_blank" rel="noopener noreferrer">Open live demo</a>}
          {p.github && <a className="btn ghost" href={p.github} target="_blank" rel="noopener noreferrer">View source</a>}
        </div>
      </div>
    </div>
  );
}
