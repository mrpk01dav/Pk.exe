import { journey } from '../data/journey';
export default function Journey() {
  return (
    <section id="journey" className="sec alt">
      <div className="wrap reveal"><p className="eyebrow">04 / Journey</p><h2>The path so far.</h2>
        <ol className="timeline">
          {journey.map((j, i) => (
            <li key={i} className={j.when === 'Future' ? 'future' : ''}><time>{j.when}</time><h3>{j.title}</h3><p className="muted">{j.text}</p></li>))}
        </ol>
      </div>
    </section>
  );
}
