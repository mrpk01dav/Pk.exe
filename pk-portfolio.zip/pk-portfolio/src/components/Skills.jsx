import { skills } from '../data/skills';
export default function Skills() {
  return (
    <section id="skills" className="sec alt">
      <div className="wrap reveal"><p className="eyebrow">02 / Skills</p><h2>What I'm working on.</h2>
        <div className="grid3">
          {skills.map((g) => (
            <article className="card" key={g.group}><h3>{g.group}</h3>
              <ul className="list">{g.items.map((i) => (
                <li key={i.name}><span>{i.name}</span><b className={'tag ' + i.status.toLowerCase()}>{i.status}</b></li>))}</ul>
            </article>))}
        </div>
      </div>
    </section>
  );
}
