import { useEffect, useRef, useState } from 'react';
import { projects } from '../data/projects';
import ProjectDetails from './ProjectDetails';

export default function Projects() {
  const [openId, setOpenId] = useState(null);
  const opener = useRef(null);
  useEffect(() => {
    const fromHash = () => { const h = location.hash.slice(1); if (projects.some((p) => p.id === h)) setOpenId(h); };
    fromHash(); addEventListener('hashchange', fromHash);
    return () => removeEventListener('hashchange', fromHash);
  }, []);
  const close = () => { setOpenId(null); history.replaceState(null, '', '#projects'); opener.current?.focus(); };
  const open = (p, e) => { opener.current = e.currentTarget; setOpenId(p.id); history.replaceState(null, '', '#' + p.id); };
  const current = projects.find((p) => p.id === openId);
  return (
    <section id="projects" className="sec">
      <div className="wrap reveal"><p className="eyebrow">03 / Projects</p><h2>Things I've built.</h2>
        <div className="grid3">
          {projects.map((p) => (
            <article className="card proj" key={p.id}>
              <div className="thumb" aria-hidden="true"><span>{p.name.split(' ')[0]}</span></div>
              <div className="meta"><span>{p.category}</span><b className="tag">{p.status}</b></div>
              <h3>{p.name}</h3><p className="muted">{p.description}</p>
              <ul className="chips">{p.stack.map((s) => <li key={s}>{s}</li>)}</ul>
              <div className="row">
                <button className="btn sm" onClick={(e) => open(p, e)}>Details</button>
                {p.live && <a className="btn sm ghost" href={p.live} target="_blank" rel="noopener noreferrer">Live demo</a>}
                {p.github && <a className="btn sm ghost" href={p.github} target="_blank" rel="noopener noreferrer">Source</a>}
              </div>
            </article>))}
          <article className="card proj empty"><p className="muted">More projects will appear here as I build them.</p></article>
        </div>
      </div>
      {current && <ProjectDetails project={current} onClose={close} />}
    </section>
  );
}
