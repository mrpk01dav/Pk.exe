import { useEffect, useState } from 'react';
import { profile } from '../data/profile';
const links = ['Home', 'About', 'Skills', 'Projects', 'Journey', 'Contact'];

export default function Navbar({ active, theme, setTheme }) {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const k = (e) => e.key === 'Escape' && setOpen(false);
    addEventListener('keydown', k);
    return () => removeEventListener('keydown', k);
  }, []);
  return (
    <header className="nav">
      <div className="wrap nav-in">
        <a href="#home" className="logo" aria-label="PK.exe home">PK<span>.exe</span></a>
        <nav id="menu" className={open ? 'open' : ''} aria-label="Primary">
          {links.map((l) => (
            <a key={l} href={'#' + l.toLowerCase()} className={active === l.toLowerCase() ? 'on' : ''}
               aria-current={active === l.toLowerCase() ? 'true' : undefined} onClick={() => setOpen(false)}>{l}</a>
          ))}
          {profile.resume
            ? <a className="btn sm" href={profile.resume} download>Resume</a>
            : <span className="btn sm ghost" aria-disabled="true" title="Resume will be added soon">Resume · soon</span>}
        </nav>
        <button className="icon" aria-label={'Switch to ' + (theme === 'dark' ? 'light' : 'dark') + ' theme'}
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>{theme === 'dark' ? '☀' : '☾'}</button>
        <button className="icon burger" aria-label="Toggle menu" aria-expanded={open} aria-controls="menu" onClick={() => setOpen(!open)}>{open ? '✕' : '☰'}</button>
      </div>
    </header>
  );
}
