import { profile } from '../data/profile';
import Terminal from './Terminal';
export default function Hero() {
  const s = profile.status;
  return (
    <section id="home" className="hero">
      <div className="glow" aria-hidden="true" />
      <div className="wrap hero-in">
        <div>
          <p className="eyebrow">{profile.brand} — {profile.tagline}</p>
          <h1>Hello, World! I'm <em>{profile.name}.</em></h1>
          <p className="lead2">{profile.headline}</p>
          <p className="muted">{profile.intro}</p>
          <div className="row">
            <a className="btn" href="#projects">Explore My Work</a>
            <a className="btn ghost" href="#contact">Contact Me</a>
          </div>
          <dl className="status">
            <div><dt>Currently learning</dt><dd>{s.learning}</dd></div>
            <div><dt>Currently building</dt><dd>{s.building}</dd></div>
            <div><dt>Currently exploring</dt><dd>{s.exploring}</dd></div>
          </dl>
        </div>
        <Terminal />
      </div>
    </section>
  );
}
