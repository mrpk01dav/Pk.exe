import { useState } from 'react';
import { profile } from '../data/profile';
const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function Contact() {
  const [state, setState] = useState({ s: 'idle', msg: '' });
  const [err, setErr] = useState({});
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try { await navigator.clipboard.writeText(profile.email); setCopied(true); setTimeout(() => setCopied(false), 1800); } catch { /* ignore */ }
  };
  const submit = async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.currentTarget));
    if (f.website) return; // honeypot: bots fill this hidden field
    const x = {};
    if (!f.name.trim()) x.name = 'Please enter your name.';
    if (!re.test(f.email.trim())) x.email = 'Please enter a valid email.';
    if (!f.subject.trim()) x.subject = 'Please add a subject.';
    if (f.message.trim().length < 10) x.message = 'Message should be at least 10 characters.';
    setErr(x); if (Object.keys(x).length) return;
    if (!profile.formEndpoint) return setState({ s: 'setup', msg: 'The contact form is not connected yet (owner setup pending). Your message was NOT sent.' });
    setState({ s: 'loading', msg: '' });
    try {
      const r = await fetch(profile.formEndpoint, { method: 'POST', headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: f.name, email: f.email, subject: f.subject, message: f.message }) });
      if (!r.ok) throw new Error();
      setState({ s: 'ok', msg: 'Message sent. Thank you!' }); e.currentTarget.reset();
    } catch { setState({ s: 'fail', msg: 'Sending failed. Please try again later.' }); }
  };
  const Field = ({ n, label, type = 'text', area }) => {
    const P = area ? 'textarea' : 'input';
    return (<div className="field"><label htmlFor={'c-' + n}>{label}</label>
      <P id={'c-' + n} name={n} type={area ? undefined : type} rows={area ? 5 : undefined} required maxLength={area ? 2000 : 150}
         aria-invalid={!!err[n]} aria-describedby={err[n] ? 'e-' + n : undefined} />
      {err[n] && <small id={'e-' + n} role="alert">{err[n]}</small>}</div>);
  };
  const soc = Object.entries(profile.social).filter(([, v]) => v);
  return (
    <section id="contact" className="sec">
      <div className="wrap grid2 reveal">
        <div><p className="eyebrow">05 / Contact</p><h2>Let's connect.</h2>
          <p className="muted">Have an idea, opportunity or something interesting to build together? Let's connect.</p>
          <div className="row">
            {profile.email && <button className="btn sm" onClick={copy}>{copied ? 'Copied ✓' : 'Copy email'}</button>}
            {soc.map(([k, v]) => <a key={k} className="btn sm ghost" href={v} target="_blank" rel="noopener noreferrer">{k[0].toUpperCase() + k.slice(1)}</a>)}
            {profile.resume && <a className="btn sm ghost" href={profile.resume} download>Download resume</a>}
          </div>
        </div>
        <form className="card" onSubmit={submit} noValidate>
          <Field n="name" label="Name" /><Field n="email" label="Email" type="email" />
          <Field n="subject" label="Subject" /><Field n="message" label="Message" area />
          <input className="hp" name="website" tabIndex={-1} autoComplete="off" aria-hidden="true" />
          <button className="btn" disabled={state.s === 'loading'}>{state.s === 'loading' ? 'Sending…' : 'Send message'}</button>
          {state.msg && <p role="status" className={'note ' + state.s}>{state.msg}</p>}
        </form>
      </div>
    </section>
  );
}
