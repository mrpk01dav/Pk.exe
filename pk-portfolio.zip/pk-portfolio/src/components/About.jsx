import { profile } from '../data/profile';
export default function About() {
  return (
    <section id="about" className="sec">
      <div className="wrap grid2 reveal">
        <div><p className="eyebrow">01 / About</p><h2>Learning by building.</h2>
          {profile.about.map((p, i) => <p key={i} className="muted">{p}</p>)}</div>
        <div className="stack">
          <article className="card"><h3>Education</h3><p>{profile.education.degree}</p>
            <p className="muted">{profile.education.school}</p><p className="muted">{profile.education.status}</p></article>
          <article className="card"><h3>Interests</h3>
            <ul className="chips">{profile.interests.map((i) => <li key={i}>{i}</li>)}</ul></article>
        </div>
      </div>
    </section>
  );
}
