import { useRef, useState, useEffect } from 'react';
import { profile } from '../data/profile';
import { skills } from '../data/skills';
import { projects } from '../data/projects';
import { journey } from '../data/journey';

const go = (id) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
const cmds = {
  help: () => ['Available commands:', 'help  about  skills  projects  journey  contact  resume  clear'],
  about: () => { go('about'); return [profile.education.degree, profile.education.school, profile.education.status]; },
  skills: () => { go('skills'); return skills.flatMap((g) => [g.group + ':', ...g.items.map((i) => '  - ' + i.name + ' [' + i.status + ']')]); },
  projects: () => { go('projects'); return projects.map((p) => p.name + ' [' + p.status + ']'); },
  journey: () => { go('journey'); return journey.map((j) => j.when + ' — ' + j.title); },
  contact: () => { go('contact'); return [profile.email ? 'Email: ' + profile.email : 'Email not added yet — use the contact form.', 'GitHub: ' + profile.social.github]; },
  resume: () => {
    if (!profile.resume) return ['Resume has not been added yet.'];
    window.open(profile.resume, '_blank', 'noopener'); return ['Opening resume…'];
  }
};

export default function Terminal() {
  const [lines, setLines] = useState([{ t: 'Welcome to PK.exe. Type "help" to begin.' }]);
  const [val, setVal] = useState('');
  const hist = useRef([]); const idx = useRef(0);
  const box = useRef(null);
  useEffect(() => { if (box.current) box.current.scrollTop = box.current.scrollHeight; }, [lines]);

  const run = (e) => {
    e.preventDefault();
    const raw = val.trim(); setVal('');
    if (!raw) return;
    hist.current.push(raw); idx.current = hist.current.length;
    const c = raw.toLowerCase();
    if (c === 'clear') return setLines([]);
    const out = cmds[c] ? cmds[c]() : ['Command not found: ' + raw.slice(0, 40) + '. Type "help".'];
    setLines((l) => [...l, { t: 'visitor@pk.exe:~$ ' + raw, cmd: true }, ...out.map((t) => ({ t }))]);
  };
  const key = (e) => {
    if (e.key === 'ArrowUp') { e.preventDefault(); idx.current = Math.max(0, idx.current - 1); setVal(hist.current[idx.current] || ''); }
    if (e.key === 'ArrowDown') { e.preventDefault(); idx.current = Math.min(hist.current.length, idx.current + 1); setVal(hist.current[idx.current] || ''); }
  };
  return (
    <div className="term" role="region" aria-label="Interactive terminal" onClick={() => document.getElementById('term-in')?.focus({ preventScroll: true })}>
      <div className="term-bar"><i /><i /><i /><span>pk.exe — terminal</span></div>
      <div className="term-out" ref={box} aria-live="polite">
        {lines.map((l, i) => <div key={i} className={l.cmd ? 'cmd' : ''}>{l.t}</div>)}
      </div>
      <form onSubmit={run} className="term-form">
        <label htmlFor="term-in">visitor@pk.exe:~$</label>
        <input id="term-in" value={val} onChange={(e) => setVal(e.target.value)} onKeyDown={key}
               autoComplete="off" autoCapitalize="off" spellCheck="false" enterKeyHint="send" />
      </form>
    </div>
  );
}
