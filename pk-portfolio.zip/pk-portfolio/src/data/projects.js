// EDIT HERE: add a new project by appending an object. Nothing else needs changing.
// status: 'In Development' | 'Live' (use Live only after you verified it works).
export const projects = [
  {
    id: 'chronos',
    name: 'Chronos — Task Planner',
    category: 'Productivity app',
    status: 'In Development',
    description: 'Chronos is a productivity-focused task planning application designed to help users organise daily, weekly, monthly and yearly activities.',
    stack: ['AI Studio'], // TODO: update after checking the source code
    features: [], // TODO: list only features you have tested in the deployed app
    live: 'https://chronos-task-planne.ai.studio',
    github: 'https://github.com/mrpk01dav/Chronos',
    detail: {
      problem: 'Keeping daily, weekly, monthly and yearly plans in one place.',
      approach: 'TODO: describe your design approach.',
      limitations: 'TODO: list known limitations after testing.',
      lessons: 'TODO: write what you learned building it.',
      screenshots: [] // add image paths in /public/images, e.g. '/images/chronos-1.png'
    }
  }
];
