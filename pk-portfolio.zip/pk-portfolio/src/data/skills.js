// EDIT HERE. status must be 'Learning' | 'Practising' | 'Comfortable'. Only add what is verified.
export const skills = [
  { group: 'Programming', items: [{ name: 'Python (fundamentals)', status: 'Learning' }] },
  { group: 'Web development', items: [{ name: 'HTML / CSS / JavaScript', status: 'Learning' }, { name: 'React', status: 'Learning' }] },
  { group: 'Development tools', items: [{ name: 'GitHub', status: 'Practising' }, { name: 'AI development tools', status: 'Practising' }] },
  { group: 'Currently exploring', items: [{ name: 'Artificial Intelligence', status: 'Learning' }, { name: 'Deployment (Vercel)', status: 'Learning' }] }
];
