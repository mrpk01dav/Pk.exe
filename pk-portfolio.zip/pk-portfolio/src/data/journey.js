// EDIT HERE: add milestones. Only add dates you can stand behind.
export const journey = [
  { when: '2026', title: 'Started B.Tech CSE (AI)', text: 'University of Lucknow.' },
  { when: '2026', title: 'Python fundamentals', text: 'Started building the basics.' },
  { when: '2026', title: 'Practical development', text: 'Began exploring programming and practical development.' },
  { when: '2026', title: 'Started building Chronos', text: 'A task planner.' },
  { when: '2026', title: 'Communities', text: 'Exploring technical communities and opportunities.' },
  { when: 'Future', title: 'Stronger projects', text: 'Build stronger software projects and explore AI applications.' }
];
