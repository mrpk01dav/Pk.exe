// EDIT HERE: all personal info lives in this file. Empty strings = hidden until you fill them in.
export const profile = {
  name: 'Prince Kumar',
  brand: 'PK.exe',
  tagline: 'Curious Mind. Creative Builder.',
  headline: 'I turn curiosity into projects.',
  intro: "I'm a Computer Science and AI student exploring programming, creative technology and building useful digital experiences.",
  education: { degree: 'B.Tech Computer Science and Engineering (Artificial Intelligence)', school: 'University of Lucknow, Faculty of Engineering and Technology', status: 'First-year undergraduate · India' },
  about: [
    "I'm Prince Kumar, a first-year B.Tech student in Computer Science and Engineering (Artificial Intelligence) at the University of Lucknow.",
    "I'm interested in technology, programming and creating digital products that solve everyday problems.",
    "I'm currently strengthening my programming fundamentals, exploring AI tools and learning how real-world applications are designed, developed and deployed.",
    'I believe in learning by building, experimenting and improving one project at a time.'
  ],
  status: { learning: 'Python fundamentals', building: 'Chronos', exploring: 'Web development and AI' },
  interests: ['Programming', 'Artificial Intelligence', 'Creative technology', 'Building useful digital products'],
  // Put your PDF in /public and set e.g. '/resume.pdf'. Empty = button shows "coming soon".
  resume: '',
  email: '', // TODO: add your email
  social: { github: 'https://github.com/mrpk01dav', linkedin: '', instagram: '' }, // TODO: add LinkedIn / Instagram URLs
  formEndpoint: import.meta.env.VITE_FORM_ENDPOINT || ''
};
